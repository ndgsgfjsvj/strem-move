package com.dooo.android.list;

public class UpdateList {
    private String Whats_New;

    public UpdateList(String whats_New) {
        Whats_New = whats_New;
    }

    public String getWhats_New() {
        return Whats_New;
    }

    public void setWhats_New(String whats_New) {
        Whats_New = whats_New;
    }
}
